<!DOCTYPE html>
<html lang="{{ get_lang() }}">
@include('godesk::index.head')
@include('godesk::index.body')
</html>
