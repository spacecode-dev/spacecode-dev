<p class="mt-8 text-center text-xs text-80">
    <a href="https://spacecode.dev" class="text-primary dim no-underline">SpaceCode</a>
    <span class="px-1">&middot;</span>
    &copy; {{ date('Y') }} SpaceCode LLC - By Vladlen Beilik.
    <span class="px-1">&middot;</span>
    v{{ GoDesk::version() }}
</p>
