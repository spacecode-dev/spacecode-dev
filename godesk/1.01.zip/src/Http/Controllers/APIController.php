<?php

namespace SpaceCode\GoDesk\Http\Controllers;

class APIController extends Controller
{

}