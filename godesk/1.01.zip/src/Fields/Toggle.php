<?php

namespace SpaceCode\GoDesk\Fields;

use Laravel\Nova\Fields\Field;

class Toggle extends Field
{
    /**
     * @var string
     */
    public $component = 'toggle';

    /**
     * @param $color
     * @return Toggle
     */
    public function color($color): Toggle
    {
        return $this->withMeta([
            'color' => $color
        ]);
    }
}