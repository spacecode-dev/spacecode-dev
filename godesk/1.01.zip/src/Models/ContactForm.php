<?php
namespace SpaceCode\GoDesk\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class ContactForm extends Model
{
    use SoftDeletes;

    protected $guarded = ['id'];

    /**
     * @var array
     */
    protected $casts = [
        'data' => 'array'
    ];

    /**
     * @var array
     */
    public static $statuses = ['new', 'pending', 'processed', 'completed', 'canceled', 'deleted'];

    /**
     * Request constructor.
     * @param array $attributes
     */
    public function __construct(array $attributes = [])
    {
        parent::__construct($attributes);
        $this->setTable('contact_form');
    }
}
