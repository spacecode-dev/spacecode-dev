<?php

namespace SpaceCode\GoDesk\Resources;

use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\Translation\Translator;
use Laravel\Nova\Fields\Code;
use Illuminate\Http\Request;
use Laravel\Nova\Fields\ID;
use Laravel\Nova\Fields\Text;
use Laravel\Nova\Resource;
use SpaceCode\GoDesk\GoDesk;
use SpaceCode\GoDesk\Traits\Resolve;

class Template extends Resource
{
    use Resolve;

    /**
     * @var string
     */
    public static $model = \SpaceCode\GoDesk\Models\Template::class;

    /**
     * @var string
     */
    public static $title = 'title';

    /**
     * @var array
     */
    public static $search = [
        'title',
    ];

    /**
     * @return string
     */
    public static function group(): string
    {
        return __('Other');
    }

    /**
     * @return array|string|null
     */
    public static function label()
    {
        return __('Templates');
    }

    /**
     * @return array|string|null
     */
    public static function singularLabel()
    {
        return __('Template');
    }

    /**
     * @return array|Application|Translator|string|null
     */
    public static function createButtonLabel()
    {
        return __('Create');
    }

    /**
     * @return array|Application|Translator|string|null
     */
    public static function updateButtonLabel()
    {
        return __('Update');
    }

    /**
     * @param Request $request
     * @return array
     */
    public function fields(Request $request)
    {
        return [

            ID::make()->asBigInt()->sortable(),

            Text::make(__('Title'), 'title')
                ->rules('required', 'max:55')
                ->creationRules('unique:templates,title')
                ->updateRules('unique:templates,title,{{resourceId}}'),

            Code::make(__('Content'), 'content')
                ->translatable(GoDesk::websiteLangsWithNames())
                ->language('php')
                ->height(1000)
                ->stacked()
        ];
    }

    /**
     * @param Request $request
     * @return array
     */
    public function cards(Request $request)
    {
        return [];
    }

    /**
     * @param Request $request
     * @return array
     */
    public function filters(Request $request)
    {
        return [];
    }

    /**
     * @param Request $request
     * @return array
     */
    public function lenses(Request $request)
    {
        return [];
    }

    /**
     * @param Request $request
     * @return array
     */
    public function actions(Request $request)
    {
        return [];
    }
}
