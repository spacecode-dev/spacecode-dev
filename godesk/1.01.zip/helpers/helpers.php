<?php

use Illuminate\Support\Str;
use SpaceCode\GoDesk\GoDesk;
use SpaceCode\GoDesk\Tools\SettingsTool;

if (!function_exists('get_settings')) {
    /**
     * @param null $settingKeys
     * @return array
     */
    function get_settings($settingKeys = null): array
    {
        return SettingsTool::getSettings($settingKeys);
    }
}

if (!function_exists('get_setting')) {
    /**
     * @param $settingKey
     * @param null $default
     * @return mixed
     */
    function get_setting($settingKey, $default = null)
    {
        $setting = SettingsTool::getSetting($settingKey, $default);
        if(is_json($setting)) {
            return json_decode($setting);
        }
        return $setting;
    }
}

if (!function_exists('get_locale_setting')) {
    /**
     * @param $settingKey
     * @return mixed
     */
    function get_locale_setting($settingKey)
    {
        $setting = SettingsTool::getSetting($settingKey);
        return json_decode($setting)->{app()->getLocale()};
    }
}

if (!function_exists('get_variables_text')) {
    /**
     * @return mixed
     */
    function get_variables_text(): string
    {
        return '<h4>' . __('List of variables to use:') . '</h4><ul class="leading-normal text-sm">
<li class="mt-1 mb-1"><span class="bg-success px-2 rounded-lg text-white">:w-title</span> ' . __('`Settings -> Website -> Title`') . '</li>
<li class="mb-1"><span class="bg-success px-2 rounded-lg text-white">:w-excerpt</span> ' . __('`Settings -> Website -> Excerpt`') . '</li>
<li class="mb-1"><span class="bg-success px-2 rounded-lg text-white">:w-desc</span> ' . __('`Settings -> Website -> Description`') . '</li>
<li class="mb-1"><span class="bg-success px-2 rounded-lg text-white">:e-name</span> ' . __('`Resource -> Content -> Name`') . '</li>
<li><span class="bg-success px-2 rounded-lg text-white">:e-excerpt</span> ' . __('`Resource -> Content -> Excerpt`') . '</li>
</ul>';
    }
}

if (! function_exists('get_favicon')) {
    /**
     * @param $path
     * @param $size
     * @return string
     */
    function get_favicon($path, $size): string
    {
        $mime = explode('.', $path)[1];
        $name = explode('.', $path)[0];
        return GoDesk::image("{$name}_{$size}.{$mime}");
    }
}

if (!function_exists('body_class')) {
    /**
     * @param $entity
     * @return mixed
     */
    function body_class($entity)
    {
        $returnClasses = collect([]);
        if($entity->indexType !== 'custom') {
            $returnClasses = $returnClasses->merge([$entity->indexType, "$entity->indexType-$entity->id", $entity->slug]);
        }
        if($entity->indexType === 'page') {
            $returnClasses = $returnClasses->merge($entity->type);
            if($entity->type === 'home') {
                $returnClasses = $returnClasses->reject(function ($class) use($entity) {
                    return $class === "$entity->indexType-$entity->id" || $class === $entity->slug || $class === $entity->indexType;
                });
            }
        }
        if(is_array($entity->indexClasses) && count($entity->indexClasses) > 0) {
            $returnClasses = $returnClasses->merge($entity->indexClasses);
        }
        return $returnClasses->values()->unique()->implode(' ');
    }
}

if (!function_exists('robots_all')) {
    /**
     * @param $type
     * @param $index
     * @return string
     */
    function robots_all($type, $index): string
    {
        $indexing = collect($index)->filter();
        if(get_setting('indexing_' . $type . '_priority')) {
            $indexing = collect(get_settings([
                'indexing_' . $type . '_google',
                'indexing_' . $type . '_yandex',
                'indexing_' . $type . '_bing',
                'indexing_' . $type . '_duck',
                'indexing_' . $type . '_baidu',
                'indexing_' . $type . '_yahoo'
            ]))->map(function ($value) {
                return json_decode($value)->{app()->getLocale()};
            })->filter();
        }
        return $indexing->count() > 0 ? 'index, follow' : 'noindex, nofollow';
    }
}

if (!function_exists('robots_google')) {
    /**
     * @param $type
     * @param $index
     * @return string
     */
    function robots_google($type, $index): string
    {
        $indexing = isset($index['google']) ? $index['google'] : '1';
        if(get_setting('indexing_' . $type . '_priority')) {
            $indexing = get_locale_setting('indexing_' . $type . '_google');
        }
        return $indexing ? 'index, follow' : 'noindex, nofollow';
    }
}

if (!function_exists('robots_yandex')) {
    /**
     * @param $type
     * @param $index
     * @return string
     */
    function robots_yandex($type, $index): string
    {
        $indexing = isset($index['yandex']) ? $index['yandex'] : '0';
        if(get_setting('indexing_' . $type . '_priority')) {
            $indexing = get_locale_setting('indexing_' . $type . '_yandex');
        }
        return $indexing ? 'index, follow' : 'noindex, nofollow';
    }
}

if (!function_exists('robots_bing')) {
    /**
     * @param $type
     * @param $index
     * @return string
     */
    function robots_bing($type, $index): string
    {
        $indexing = isset($index['bing']) ? $index['bing'] : '0';
        if(get_setting('indexing_' . $type . '_priority')) {
            $indexing = get_locale_setting('indexing_' . $type . '_bing');
        }
        return $indexing ? 'index, follow' : 'noindex, nofollow';
    }
}

if (!function_exists('robots_duck')) {
    /**
     * @param $type
     * @param $index
     * @return string
     */
    function robots_duck($type, $index): string
    {
        $indexing = isset($index['duck']) ? $index['duck'] : '0';
        if(get_setting('indexing_' . $type . '_priority')) {
            $indexing = get_locale_setting('indexing_' . $type . '_duck');
        }
        return $indexing ? 'index, follow' : 'noindex, nofollow';
    }
}

if (!function_exists('robots_baidu')) {
    /**
     * @param $type
     * @param $index
     * @return string
     */
    function robots_baidu($type, $index): string
    {
        $indexing = isset($index['baidu']) ? $index['baidu'] : '0';
        if(get_setting('indexing_' . $type . '_priority')) {
            $indexing = get_locale_setting('indexing_' . $type . '_baidu');
        }
        return $indexing ? 'index, follow' : 'noindex, nofollow';
    }
}

if (!function_exists('robots_yahoo')) {
    /**
     * @param $type
     * @param $index
     * @return string
     */
    function robots_yahoo($type, $index): string
    {
        $indexing = isset($index['yahoo']) ? $index['yahoo'] : '0';
        if(get_setting('indexing_' . $type . '_priority')) {
            $indexing = get_locale_setting('indexing_' . $type . '_yahoo');
        }
        return $indexing ? 'index, follow' : 'noindex, nofollow';
    }
}

if (!function_exists('meta_title')) {
    /**
     * @param $entity
     * @return string
     */
    function meta_title($entity): string
    {
        $global = get_locale_setting('indexing_' . $entity->indexType . '_meta_title');
        $result = strip_tags($entity->title);
        if(get_setting('indexing_' . $entity->indexType . '_priority') && !empty($global)) {
            $result = strip_tags($global);
        } else if (!empty($entity->meta_title)) {
            $result = strip_tags($entity->meta_title);
        }
        return GoDesk::withVariables($result, $entity);
    }
}

if (!function_exists('meta_description')) {
    /**
     * @param $entity
     * @return string
     */
    function meta_description($entity): string
    {
        $global = get_locale_setting('indexing_' . $entity->indexType . '_meta_description');
        $result = substr(strip_tags($entity->meta_description), 0, 155);
        if(get_setting('indexing_' . $entity->indexType . '_priority') && !empty($global)) {
            $result = substr(strip_tags($global), 0, 155);
        } else if (!empty($entity->excerpt)) {
            $result = substr(strip_tags($entity->excerpt), 0, 155);
        }
        return GoDesk::withVariables($result, $entity);
    }
}

if (!function_exists('is_parent')) {
    /**
     * @param $entity
     * @return string
     */
    function is_parent($entity): string
    {
        if(isset($entity->parent_id) && !empty($entity->parent_id)) {
            return $entity->parent->url;
        }
        return '';
    }
}

if (!function_exists('is_pagination')) {
    /**
     * @param $entity
     * @param $type
     * @return string|string[]
     */
    function is_pagination($entity, $type)
    {
        if(property_exists($entity, 'paginationItem') && !empty($entity->paginationItem) && $entity->paginationItem->count() > 0) {
            if($type === 'first') {
                return $entity->getUrl(true);
            } elseif ($type === 'last') {
                return url()->current() . '?page=' . $entity->paginationItem->lastPage();
            } elseif ($type === 'next') {
                return $entity->paginationItem->nextPageUrl();
            } elseif ($type === 'prev') {
                return str_replace('?page=1', '', $entity->paginationItem->previousPageUrl());
            }
        }
        return '';
    }
}


if (!function_exists('get_lang')) {
    /**
     * @return string
     */
    function get_lang(): string
    {
        if(request()->query('lang')) {
            return request()->query('lang');
        }
        return app()->getLocale();
    }
}

if (!function_exists('is_json')) {
    /**
     * @param $string
     * @return bool
     */
    function is_json($string): bool
    {
        json_decode($string);
        return (json_last_error() === JSON_ERROR_NONE);
    }
}

if (!function_exists('is_tag_index')) {
    /**
     * @return bool
     */
    function is_tag_index(): bool
    {
        if(get_setting('use_blog') && !get_setting('blog_hide_tags')) {
            return true;
        }
        return false;
    }
}

