<?php

foreach ($items as $item) {
    echo $item['loc']."\n";
}
