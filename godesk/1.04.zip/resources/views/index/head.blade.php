<head>
{!! "\t" !!}@include('godesk::index.head.gtm-head')
{!! "\t" !!}@include('godesk::index.head.favicon')
{!! "\t" !!}@include('godesk::index.head.robots')
{!! "\t" !!}@include('godesk::index.head.document-state')
{!! "\t" !!}@include('godesk::index.head.meta')
{!! "\t" !!}@include('godesk::index.head.respond')
{!! "\t" !!}@include('godesk::index.head.css')
{!! "\t" !!}@include('godesk::index.head.meta-tags')
{!! "\t" !!}@include('godesk::index.head.fb-pageView')
{!! "\t" !!}@include('godesk::index.head.linkedin')
</head>
