<!-- Index -->
{!! "\t" !!}<meta name="document-state" content="@yield('documentState')">
{!! "\t<!-- End Index -->\n\n" !!}