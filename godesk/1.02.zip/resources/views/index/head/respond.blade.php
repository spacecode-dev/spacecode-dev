<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
{!! "\t" !!}<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
{!! "\t" !!}<!--[if lt IE 9]>
{!! "\t" !!}<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
{!! "\t" !!}<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
{!! "\t" !!}<![endif]-->{!! "\n\n" !!}