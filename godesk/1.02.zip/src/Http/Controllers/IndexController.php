<?php

namespace SpaceCode\GoDesk\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Str;
use SpaceCode\GoDesk\GoDesk;
use SpaceCode\GoDesk\Models;
use Illuminate\Support\Facades\View;
use SpaceCode\GoDesk\Models\Settings;
use SpaceCode\GoDesk\Traits\Resolve;
use stdClass;

class IndexController extends Controller
{
    use Resolve;

    /**
     * IndexController constructor.
     * @param $settings
     */
    public function __construct($settings = false)
    {
        if (!$settings)
            $settings = collect();
        $settings->put('tracking', (object)[
            'gtm' => get_setting('tracking_gtm'),
            'fb' => get_setting('tracking_fb'),
        ]);
        $settings->put('author', (object)[
            'title' => 'SpaceCode',
            'link' => 'https://spacecode.dev'
        ]);
        $settings->put('me', url(''));
        $settings->put('favicon', null);
        $favicon = get_setting('website_favicon');
        if ($favicon) {
            $settings->put('favicon', "<!-- Favicon -->\n\t<link rel='icon' sizes='180x180' href='" . get_favicon($favicon, '180') . "' />\n\t<link rel='icon' sizes='32x32' href='" . get_favicon($favicon, '32') . "' />\n\t<!-- End Favicon -->\n\n");
        }
        View::share('settings', (object)$settings->toArray());
    }

    /**
     * @param $slug
     * @return object
     */
    public function index($slug): object
    {
        $request = request();

        /* Get prefix from segment */
        $prefix = $this->getRequestPrefix($request);
        $lang = app()->getLocale();

        $valuePrefix = get_setting('prefix_' . $prefix);
        $slug = collect(explode('/', $slug))->filter(function($el) use($lang, $valuePrefix) {
            return $el !== $lang && $el !== $valuePrefix;
        })->filter()->values();
        if($prefix === 'page') {
            $entity = $this->pageIndex($slug);
        } else if ($prefix === 'post') {
            $entity = $this->postIndex($slug);
        } else if ($prefix === 'post_tag') {
            $entity = $this->postTagIndex($slug);
        } else if ($prefix === 'post_category') {
            $entity = $this->postCategoryIndex($slug);
        } else {
            return abort(404);
        }
        $entity->locale = $lang;
        $entity->indexType = $prefix;

        return $entity->translateMutator();
    }

    /**
     * @param $title
     * @param $classes
     * @param $view
     * @return stdClass
     */
    public function customIndex($title, $classes, $view): stdClass
    {
        $entity = new stdClass();
        $entity->locale = app()->getLocale();
        $entity->index = null;
        $entity->indexType = 'custom';
        $entity->indexClasses = $classes;
        $entity->title = $title;
        $entity->indexView = $view;
        return $entity;
    }

    /**
     * @param $slug
     * @return object
     */
    private function pageIndex($slug): object
    {
        if(!$slug->count()) {
            $entity = Models\Page::where(['type' => 'home', 'guard_name' => 'web', 'status' => 'published'])->firstOrFail();
        } elseif ($slug->count() === 1) {
            $entity = Models\Page::whereSlug($slug->first())->where(['type' => 'page', 'guard_name' => 'web', 'status' => 'published'])->firstOrFail();
        } else {
            $entity = Models\Page::whereSlug($slug->last())->where(['type' => 'page', 'guard_name' => 'web', 'status' => 'published'])->firstOrFail();
        }
        $entity->indexModel = Models\Page::class;
        $entity->indexView = $this->getIndexView($entity);
        return $entity;
    }

    /**
     * @param $slug
     * @return object
     */
    private function postIndex($slug): object
    {
        $entity = Models\Post::whereSlug($slug)->where(['guard_name' => 'web', 'status' => 'published'])->firstOrFail();
        $entity->indexModel = Models\Post::class;
        $entity->indexView = $this->getIndexView($entity);
        return $entity;
    }

    /**
     * @param $slug
     * @return object
     */
    private function postTagIndex($slug): object
    {
        if(get_setting('blog_hide_tags')) {
            return abort(404);
        }
        $entity = Models\PostTag::whereSlug($slug)->where(['guard_name' => 'web'])->firstOrFail();
        $entity->indexModel = Models\PostTag::class;
        $entity->indexView = $this->getIndexView($entity);
        return $entity;
    }

    /**
     * @param $slug
     * @return object
     */
    private function postCategoryIndex($slug): object
    {
        if ($slug->count() === 1) {
            $entity = Models\PostCategory::whereSlug($slug->first())->where(['guard_name' => 'web'])->firstOrFail();
        } else {
            $entity = $slug->reduce(function ($item, $s) {
                return ($item->children()->where('slug', $s)->firstOrFail());
            }, Models\PostCategory::whereSlug($slug)->where(['guard_name' => 'web'])->with('children')->firstOrFail());
        }
        $entity->indexModel = Models\PostCategory::class;
        $entity->indexView = $this->getIndexView($entity);
        return $entity;
    }

    /**
     * @param $request
     * @return string|string[]
     */
    private function getRequestPrefix($request)
    {
        $prefixes = Settings::where('key', 'LIKE', 'prefix_%');
        if(GoDesk::isMultiLang()) {
            $segment = in_array($request->segment(1), get_setting('website_langs')) ? $request->segment(2) : $request->segment(1);
            if(in_array($segment, $prefixes->pluck('value', 'key')->values()->toArray())) {
                return str_replace('prefix_', '', $prefixes->where('value', $segment)->pluck('key')->first());
            }
        } else {
            if(in_array($request->segment(1), $prefixes->pluck('value', 'key')->values()->toArray())) {
                return str_replace('prefix_', '', $prefixes->where('value', $request->segment(1))->pluck('key')->first());
            }
        }
        return 'page';
    }

    /**
     * @param $entity
     * @return string
     */
    private function getIndexView($entity): string
    {
        return !$entity->template_id ? 'godesk::index.templates.content' : 'godesk-index::templates.' . Str::of($entity->template->title)->slug('-') . '.' . app()->getLocale();
    }
}