<!DOCTYPE html>
<html lang="{{ GoDesk::locale() }}">
@include('godesk::index.head')
@include('godesk::index.body')
</html>
