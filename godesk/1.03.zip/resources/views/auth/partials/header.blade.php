<div class="mx-auto py-6 max-w-sm text-center text-90">
    @include('godesk::auth.partials.logo')
</div>
