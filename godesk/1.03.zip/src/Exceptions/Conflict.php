<?php

namespace SpaceCode\GoDesk\Exceptions;

use InvalidArgumentException;

class Conflict extends InvalidArgumentException
{
    //
}
