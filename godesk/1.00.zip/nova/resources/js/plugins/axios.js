import axios from 'axios'

window.axios = axios
